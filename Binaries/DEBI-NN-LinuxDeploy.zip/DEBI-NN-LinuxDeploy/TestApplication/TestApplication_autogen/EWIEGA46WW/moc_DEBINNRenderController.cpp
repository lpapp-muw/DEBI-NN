/****************************************************************************
** Meta object code from reading C++ file 'DEBINNRenderController.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../TestApplication/DEBINNRenderController.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'DEBINNRenderController.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_muw__DEBINNRenderController_t {
    const uint offsetsAndSize[32];
    char stringdata0[223];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_muw__DEBINNRenderController_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_muw__DEBINNRenderController_t qt_meta_stringdata_muw__DEBINNRenderController = {
    {
QT_MOC_LITERAL(0, 27), // "muw::DEBINNRenderController"
QT_MOC_LITERAL(28, 14), // "startAnimation"
QT_MOC_LITERAL(43, 0), // ""
QT_MOC_LITERAL(44, 13), // "stopAnimation"
QT_MOC_LITERAL(58, 14), // "resetAnimation"
QT_MOC_LITERAL(73, 14), // "setLinearSpeed"
QT_MOC_LITERAL(88, 12), // "aLinearSpeed"
QT_MOC_LITERAL(101, 12), // "setLookSpeed"
QT_MOC_LITERAL(114, 10), // "aLookSpeed"
QT_MOC_LITERAL(125, 11), // "selectModel"
QT_MOC_LITERAL(137, 11), // "aModelIndex"
QT_MOC_LITERAL(149, 10), // "grabScreen"
QT_MOC_LITERAL(160, 10), // "aViewIndex"
QT_MOC_LITERAL(171, 21), // "std::function<void()>"
QT_MOC_LITERAL(193, 8), // "aOnSaved"
QT_MOC_LITERAL(202, 20) // "autoPilotModelScroll"

    },
    "muw::DEBINNRenderController\0startAnimation\0"
    "\0stopAnimation\0resetAnimation\0"
    "setLinearSpeed\0aLinearSpeed\0setLookSpeed\0"
    "aLookSpeed\0selectModel\0aModelIndex\0"
    "grabScreen\0aViewIndex\0std::function<void()>\0"
    "aOnSaved\0autoPilotModelScroll"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_muw__DEBINNRenderController[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x0a,    1 /* Public */,
       3,    0,   75,    2, 0x0a,    2 /* Public */,
       4,    0,   76,    2, 0x0a,    3 /* Public */,
       5,    1,   77,    2, 0x0a,    4 /* Public */,
       7,    1,   80,    2, 0x0a,    6 /* Public */,
       9,    1,   83,    2, 0x0a,    8 /* Public */,
      11,    2,   86,    2, 0x0a,   10 /* Public */,
      11,    1,   91,    2, 0x2a,   13 /* Public | MethodCloned */,
      11,    0,   94,    2, 0x2a,   15 /* Public | MethodCloned */,
      15,    0,   95,    2, 0x0a,   16 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::Double,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 13,   12,   14,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void muw::DEBINNRenderController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DEBINNRenderController *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->startAnimation(); break;
        case 1: _t->stopAnimation(); break;
        case 2: _t->resetAnimation(); break;
        case 3: _t->setLinearSpeed((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 4: _t->setLookSpeed((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 5: _t->selectModel((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->grabScreen((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<std::function<void()>>>(_a[2]))); break;
        case 7: _t->grabScreen((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->grabScreen(); break;
        case 9: _t->autoPilotModelScroll(); break;
        default: ;
        }
    }
}

const QMetaObject muw::DEBINNRenderController::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_muw__DEBINNRenderController.offsetsAndSize,
    qt_meta_data_muw__DEBINNRenderController,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_muw__DEBINNRenderController_t
, QtPrivate::TypeAndForceComplete<DEBINNRenderController, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<std::function<void()>, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *muw::DEBINNRenderController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *muw::DEBINNRenderController::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_muw__DEBINNRenderController.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int muw::DEBINNRenderController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
