/********************************************************************************
** Form generated from reading UI file 'DEBINNRenderController.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DEBINNRENDERCONTROLLER_H
#define UI_DEBINNRENDERCONTROLLER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DEBINNRenderController
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QLabel *label;
    QDoubleSpinBox *doubleSpinBoxDelta;
    QLabel *label_4;
    QDoubleSpinBox *doubleSpinBoxLookSpeed;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBoxLinearSpeed;
    QPushButton *pushButtonStart;
    QPushButton *pushButtonStop;
    QPushButton *pushButtonReset;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_4;
    QScrollBar *scrollbarModels;
    QPushButton *pushButtonSaveView;
    QPushButton *pushButtonSaveViewBatch;
    QTextBrowser *textBrowser;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *DEBINNRenderController)
    {
        if (DEBINNRenderController->objectName().isEmpty())
            DEBINNRenderController->setObjectName(QString::fromUtf8("DEBINNRenderController"));
        DEBINNRenderController->resize(364, 560);
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DEBINNRenderController->sizePolicy().hasHeightForWidth());
        DEBINNRenderController->setSizePolicy(sizePolicy);
        DEBINNRenderController->setMinimumSize(QSize(300, 300));
        centralwidget = new QWidget(DEBINNRenderController);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        groupBox->setMinimumSize(QSize(200, 0));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        doubleSpinBoxDelta = new QDoubleSpinBox(groupBox);
        doubleSpinBoxDelta->setObjectName(QString::fromUtf8("doubleSpinBoxDelta"));
        doubleSpinBoxDelta->setDecimals(3);
        doubleSpinBoxDelta->setSingleStep(0.005000000000000);
        doubleSpinBoxDelta->setValue(0.010000000000000);

        gridLayout->addWidget(doubleSpinBoxDelta, 0, 1, 1, 1);

        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 1, 0, 1, 1);

        doubleSpinBoxLookSpeed = new QDoubleSpinBox(groupBox);
        doubleSpinBoxLookSpeed->setObjectName(QString::fromUtf8("doubleSpinBoxLookSpeed"));
        doubleSpinBoxLookSpeed->setValue(50.000000000000000);

        gridLayout->addWidget(doubleSpinBoxLookSpeed, 1, 1, 1, 1);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 2, 0, 1, 1);

        doubleSpinBoxLinearSpeed = new QDoubleSpinBox(groupBox);
        doubleSpinBoxLinearSpeed->setObjectName(QString::fromUtf8("doubleSpinBoxLinearSpeed"));
        doubleSpinBoxLinearSpeed->setValue(1.000000000000000);

        gridLayout->addWidget(doubleSpinBoxLinearSpeed, 2, 1, 1, 1);

        pushButtonStart = new QPushButton(groupBox);
        pushButtonStart->setObjectName(QString::fromUtf8("pushButtonStart"));

        gridLayout->addWidget(pushButtonStart, 3, 0, 1, 2);

        pushButtonStop = new QPushButton(groupBox);
        pushButtonStop->setObjectName(QString::fromUtf8("pushButtonStop"));

        gridLayout->addWidget(pushButtonStop, 4, 0, 1, 2);

        pushButtonReset = new QPushButton(groupBox);
        pushButtonReset->setObjectName(QString::fromUtf8("pushButtonReset"));

        gridLayout->addWidget(pushButtonReset, 5, 0, 1, 2);


        gridLayout_3->addWidget(groupBox, 0, 0, 1, 1);

        groupBox_2 = new QGroupBox(centralwidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(groupBox_2->sizePolicy().hasHeightForWidth());
        groupBox_2->setSizePolicy(sizePolicy2);
        groupBox_2->setMinimumSize(QSize(200, 0));
        gridLayout_4 = new QGridLayout(groupBox_2);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        scrollbarModels = new QScrollBar(groupBox_2);
        scrollbarModels->setObjectName(QString::fromUtf8("scrollbarModels"));
        scrollbarModels->setPageStep(1);
        scrollbarModels->setTracking(false);
        scrollbarModels->setOrientation(Qt::Horizontal);

        gridLayout_4->addWidget(scrollbarModels, 0, 0, 1, 1);

        pushButtonSaveView = new QPushButton(groupBox_2);
        pushButtonSaveView->setObjectName(QString::fromUtf8("pushButtonSaveView"));

        gridLayout_4->addWidget(pushButtonSaveView, 1, 0, 1, 1);

        pushButtonSaveViewBatch = new QPushButton(groupBox_2);
        pushButtonSaveViewBatch->setObjectName(QString::fromUtf8("pushButtonSaveViewBatch"));

        gridLayout_4->addWidget(pushButtonSaveViewBatch, 2, 0, 1, 1);


        gridLayout_3->addWidget(groupBox_2, 1, 0, 1, 1);

        textBrowser = new QTextBrowser(centralwidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        gridLayout_3->addWidget(textBrowser, 2, 0, 1, 1);

        DEBINNRenderController->setCentralWidget(centralwidget);
        menubar = new QMenuBar(DEBINNRenderController);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 364, 22));
        DEBINNRenderController->setMenuBar(menubar);
        statusbar = new QStatusBar(DEBINNRenderController);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        DEBINNRenderController->setStatusBar(statusbar);

        retranslateUi(DEBINNRenderController);

        QMetaObject::connectSlotsByName(DEBINNRenderController);
    } // setupUi

    void retranslateUi(QMainWindow *DEBINNRenderController)
    {
        DEBINNRenderController->setWindowTitle(QCoreApplication::translate("DEBINNRenderController", "MainWindow", nullptr));
        groupBox->setTitle(QCoreApplication::translate("DEBINNRenderController", "Camera Control", nullptr));
        label->setText(QCoreApplication::translate("DEBINNRenderController", "Delta", nullptr));
        label_4->setText(QCoreApplication::translate("DEBINNRenderController", "LookSpeed", nullptr));
        label_5->setText(QCoreApplication::translate("DEBINNRenderController", "LinearSpeed", nullptr));
        pushButtonStart->setText(QCoreApplication::translate("DEBINNRenderController", "Start", nullptr));
        pushButtonStop->setText(QCoreApplication::translate("DEBINNRenderController", "Stop", nullptr));
        pushButtonReset->setText(QCoreApplication::translate("DEBINNRenderController", "Reset", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("DEBINNRenderController", "Model Control", nullptr));
        pushButtonSaveView->setText(QCoreApplication::translate("DEBINNRenderController", "Save View", nullptr));
        pushButtonSaveViewBatch->setText(QCoreApplication::translate("DEBINNRenderController", "Batch Save View", nullptr));
        textBrowser->setHtml(QCoreApplication::translate("DEBINNRenderController", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">--- Camera Control ---</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">Allows to set up automated rotation parameters for animating the view.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style="
                        "\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Start: Starts the animation (rotate left-right) based on parameters</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Stop: Stops the animation</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Reset: Resets the view to default state.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">--- Model Control ---</span></p>\n"
""
                        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">Allows to scrool through multiple models in case they are in the /Models project folder.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Save View: Saves the given 3D view and stores it in /Screens folder in the project folder.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-"
                        "bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">--- Freehand 3D control ---</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">The 3D view can also be controlled by mouse or keyboard.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Rotate view: Right mouse button + drag</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Pan view: Left mouse button + drag</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; tex"
                        "t-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Rotate Left/Right: ALT + Left/Right arrow</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">- Rotate Up/Down: ALT + Up/Down arrow</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DEBINNRenderController: public Ui_DEBINNRenderController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEBINNRENDERCONTROLLER_H
